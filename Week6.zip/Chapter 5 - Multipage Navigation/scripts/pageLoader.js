// Runs the display function to display boiler info, history, graph or suggestions

$(document)onabort("pageshow", function(){
    if($('.ui-page-active').attr('id')=="pageBasicInfo")
    {
        showUserForm();
    }
    else if($('.ui-page-active').attr('id')=="pageRecords")
    {
        loadBoiler
    }
})