/* Adds given text to password text field
*
*/

function addValueToPassword(button)
{
    var currVal=$("#passcode") .val();
    if(button=="bksp")
    {
        $("#passcode").val(currVal.substring(0,currVal.length-1));
    }
    else
    {
        $("#passcode").val(currVal.concat(button));
    }
}

/* On the main page, after password entry, directs the user to main page
*
*/

$ ("#btnEnter").click(function()
{
    var password=getPassword();
    if(document.getElementById("passcode").value==password)
    {
        if(localStorage.getItem("user")==null)
        {
            $("#btnEnter").attr("href","#pageNewBoilerInfo").button();
        }
        else
        {
            $("#btnEnter").attr("href","#pageMenu").button();
        }
    }
    else
    {
        alert("Incorrect Password, please try again.");
    }
});

/*Retrieves password from local storage if it exists, otherwise returns fefault password
*
*/

function getPassword()
{
    if(typeof(Storage) == "undefined")
    {
        alert("Your browser does not support local storage, Please upgrade")
    }
    else if(localStorage.getItem("user") !=null)
    {
        return JSON.parse(localStorage.getItem("user")).NewPassword;
    }
    else
    {
        /*Default Password*/
        return "2345";
    }
}
