function createTable(){
    var myTable = document.createElement("table");
    document.body.appendChild(myTable);

        for(var  i = 2; i <= 100; i++) {
            var currentRow = myTable.insertRow(-1);
            var firstCell = currentRow.insertCell(0);

            i = i * Math.floor(Math.random() * 3 + 1);
            firstCell.innerHTML = i.toLocaleString('en');

            var secondCell = currentRow.insertCell(1);
            secondCell.innerHTML = (i * i).toLocaleString('en');

            var thirdCell = currentRow.insertCell(2);
            thirdCell.innerHTML = (i * i * i).toLocaleString('en')
        }
}

function regenerate() {
    var myTable = document.getElementsByTagName("table");
    document.body.removeChild(myTable[0]);
    createTable();
}