function update() {
    var selectUnits = $('#selectUnits option:selected').text();
    var units = $('#units').val();
    var unitsEntered=$('#unitsEntered');

    if(units.length===0 || $.isNumeric(units)===false){
        $('#unitsInvalid').text('Please enter a valid Units');
    } else {
        $('#unitsInvalid').text('');
        unitsEntered.text(units + ' in ' + selectUnits);
    }


}